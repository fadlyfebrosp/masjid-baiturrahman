@extends('errors::minimal')

@section('title', 'Page Expired')
@section('code', '419')
@section('message', 'Sesi Anda telah berakhir. Silakan muat ulang halaman.')
