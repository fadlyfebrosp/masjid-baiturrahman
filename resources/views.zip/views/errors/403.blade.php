@extends('errors::minimal')

@section('title', 'Forbidden')
@section('code', '403')
@section('message', 'Akses tidak diizinkan.')
